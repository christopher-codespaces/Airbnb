import React from "react";
import Card from "./Card";

function App() {
  return (
   <div className="cardcomponent">
      <div className="cardcontainer">
        <Card
          className="custom-card"
          imageSrc="../images/2.png"
          rating="5.0"
          reviews="6"
          location="USA"
          title="Life Lessons with Katie Zaferes"
          price=" 136 "
        />
      </div>
      <div className="cardcontainer">
        <Card
          className="custom-card"
          imageSrc="../images/3.png"
          rating="5.0"
          reviews="6"
          location="USA"
          title="Learn wedding photography"
          price=" 125 "
        />
      </div>
      <div className="cardcontainer">
        <Card
          className="custom-card"
          imageSrc="../images/1.png"
          rating="4.8"
          reviews="2"
          location="USA"
          title="Group Mountain Biking"
          price=" 50 "
        />
      </div>
    </div>
  );
}

export default App;
