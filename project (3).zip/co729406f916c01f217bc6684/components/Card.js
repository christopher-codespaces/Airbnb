import React from "react";

export default function Card(props) {
  const {
    className,
    imageSrc,
    rating,
    reviews,
    location,
    title,
    price
  } = props;

  return (
    <div className={`card ${className}`}>
      <img src={imageSrc} className="card--image" />
      <div className="card--stats">
        <img src="../images/star.png" className="card--star" />
        <span>{rating}</span>
        <span className="gray">({reviews}) • </span>
        <span className="gray">{location}</span>
      </div>
      <p>{title}</p>
      <p>
        <span className="bold">From ${price} / person</span> / person
      </p>
    </div>
  );
}
